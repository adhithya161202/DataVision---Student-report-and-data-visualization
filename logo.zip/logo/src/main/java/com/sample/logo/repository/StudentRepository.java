package com.sample.logo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.sample.logo.models.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
}
