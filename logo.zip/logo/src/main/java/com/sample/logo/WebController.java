package com.sample.logo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;



@Controller
public class WebController {
    @GetMapping("/login")
    public String loginPage() {
        return "login"; // This will render login.html
    }
    
    @GetMapping("/register")
    public String registrationPage() {
        return "registration"; // This will render registration.html
    }
}
