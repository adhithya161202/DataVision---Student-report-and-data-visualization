package com.sample.logo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {

    @GetMapping("/login")
    public String loginPage() {
        System.out.println(">>> Inside loginPage() method <<<");
        return "login"; // Make sure login.html exists in the templates folder
    }
    
    @GetMapping("/register")
    public String registrationPage() {
        return "registration"; // Make sure registration.html exists in the templates folder
    }
}
