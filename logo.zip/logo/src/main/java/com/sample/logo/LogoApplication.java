package com.sample.logo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogoApplication.class, args);
		

	}

}
