INSERT INTO students (name, email, department, batch_year, role)
VALUES
('John Doe', 'john@example.com', 'CSE', 2024, 'Student'),
('Jane Smith', 'jane@example.com', 'ECE', 2023, 'Faculty');

INSERT INTO event_participation (student_id, event_name, event_type, event_date)
VALUES
(1, 'Hackathon', 'Technical', '2025-02-10'),
(2, 'Dance Competition', 'Cultural', '2025-03-15');
