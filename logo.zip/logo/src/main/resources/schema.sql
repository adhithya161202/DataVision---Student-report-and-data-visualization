CREATE TABLE IF NOT EXISTS students (
    student_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    department VARCHAR(100),
    batch_year INT,
    role ENUM('Student', 'Faculty', 'Admin')
);

CREATE TABLE IF NOT EXISTS event_participation (
    participation_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id BIGINT,
    event_name VARCHAR(255) NOT NULL,
    event_type ENUM('Technical', 'Cultural', 'Sports'),
    event_date DATE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);
