package com.sample.logo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogoApplicationTests {

	@Test
	void contextLoads() {
	}

}
