
import React from 'react';

const Dashboard = () => {
    const styles = {
        dashboardContainer: {
            display: 'flex',
            height: '100vh',
            fontFamily: 'Segoe UI, Tahoma, Geneva, Verdana, sans-serif',
            backgroundColor: '#f4f7fa',
            color: '#333',
        },
        sidebar: {
            width: '250px',
            backgroundColor: '#2c3e50',
            color: '#fff',
            padding: '20px',
            display: 'flex',
            flexDirection: 'column',
        },
        sidebarHeader: {
            marginBottom: '30px',
            display: 'flex',
            justifyContent: 'space-between', 
            alignItems: 'center', 
        },
        sidebarHeaderH2: {
            margin: '0',
            fontWeight: 'bold',
            fontSize: '20px',
        },
        sidebarHeaderP: {
            margin: '5px 0',
            fontSize: '14px',
            color: '#bdc3c7',
        },
        profileSection: {
            display: 'flex',
            alignItems: 'center',
        },
        profilePic: {
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            backgroundColor: '#3498db',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '18px',
            marginRight: '10px',
            cursor: 'pointer',
        },
        sidebarMenuUl: {
            listStyle: 'none',
            padding: '0',
            margin: '0',
        },
        sidebarMenuLi: {
            marginBottom: '10px',
        },
        sidebarMenuA: {
            display: 'block',
            color: '#fff',
            textDecoration: 'none',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.3s ease',
            fontSize: '16px',
        },
        sidebarAnalyticsP: {
            color: '#bdc3c7',
            marginTop: '20px',
            marginBottom: '10px',
            fontSize: '14px',
            fontWeight: 'bold',
            paddingLeft: '15px',
        },
        sidebarAnalyticsUl: {
            listStyle: 'none',
            padding: '0',
            margin: '0',
        },
        sidebarAnalyticsLi: {
            marginBottom: '10px',
        },
        sidebarAnalyticsA: {
            display: 'block',
            color: '#fff',
            textDecoration: 'none',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.3s ease',
            fontSize: '16px',
        },
        sidebarSettingsP: {
            color: '#bdc3c7',
            marginTop: '20px',
            marginBottom: '10px',
            fontSize: '14px',
            fontWeight: 'bold',
            paddingLeft: '15px',
        },
        sidebarSettingsUl: {
            listStyle: 'none',
            padding: '0',
            margin: '0',
        },
        sidebarSettingsLi: {
            marginBottom: '10px',
        },
        sidebarSettingsA: {
            display: 'block',
            color: '#fff',
            textDecoration: 'none',
            padding: '10px 15px',
            borderRadius: '5px',
            transition: 'background-color 0.3s ease',
            fontSize: '16px',
        },
        sidebarAdmin: {
            marginTop: 'auto',
            display: 'flex',
            alignItems: 'center',
            padding: '10px',
            backgroundColor: 'rgba(255, 255, 255, 0.1)',
            borderRadius: '5px',
        },
        adminIcon: {
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            backgroundColor: '#3498db',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '18px',
            marginRight: '10px',
        },
        adminInfoP: {
            margin: '0',
            fontSize: '14px',
        },
        adminInfoPLastChild: {
            color: '#bdc3c7',
        },
        mainContent: {
            flex: '1',
            padding: '20px',
        },
        dashboardHeader: {
            marginBottom: '20px',
            borderBottom: '2px solid #ddd',
            paddingBottom: '10px',
            display: 'flex', // Use flexbox for alignment
            justifyContent: 'space-between', // Space out the title and admin info
            alignItems: 'center', // Vertically align items
        },
        dashboardHeaderH1: {
            margin: '0',
            fontSize: '24px',
            fontWeight: 'bold',
            color: '#34495e',
        },
        quickStats: {
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '20px',
            marginBottom: '20px',
        },
        statCard: {
            backgroundColor: '#fff',
            borderRadius: '8px',
            padding: '20px',
            boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
        },
        statCardH3: {
            margin: '0',
            fontSize: '18px',
            color: '#34495e',
        },
        statCardP: {
            margin: '5px 0',
            fontSize: '16px',
            color: '#7f8c8d',
        },
        statCardPLastChild: {
            fontSize: '14px',
        },
        filters: {
            display: 'flex',
            gap: '10px',
            marginBottom: '20px',
            alignItems: 'center',
        },
        filtersLabel: {
            fontSize: '16px',
            color: '#34495e',
        },
        filtersSelect: {
            padding: '10px',
            borderRadius: '5px',
            border: '1px solid #ddd',
            fontSize: '16px',
            color: '#34495e',
        },
        filtersButton: {
            backgroundColor: '#3498db',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            padding: '10px 15px',
            fontSize: '16px',
            cursor: 'pointer',
            transition: 'background-color 0.3s ease',
        },
        dataVisualizations: {
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
            gap: '20px',
        },
        dataCard: {
            backgroundColor: '#fff',
            borderRadius: '8px',
            padding: '20px',
            boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)',
        },
        dataCardH3: {
            margin: '0',
            fontSize: '20px',
            color: '#34495e',
            marginBottom: '10px',
        },
        chartPlaceholder: {
            height: '200px',
            backgroundColor: '#ecf0f1',
            borderRadius: '5px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#7f8c8d',
            fontSize: '18px',
            fontStyle: 'italic',
        },
        sidebarMenuActive: { 
            backgroundColor: 'rgba(255, 255, 255, 0.2)'
        },
        footerIcons: {
            display: 'flex',
            marginLeft: '10px'
        },
        mainIcons: {
            marginRight: '10px'
        },
        
        filtersContainer: {
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            marginBottom: '20px',
            flexWrap: 'wrap',
        },
        filterLabel: {
            fontSize: '16px',
            color: '#34495e',
        },
        filterSelect: {
            padding: '8px',
            borderRadius: '5px',
            border: '1px solid #ddd',
            fontSize: '16px',
            color: '#34495e',
            minWidth: '120px', 
        },
        applyFiltersButton: {
            backgroundColor: '#3498db',
            color: '#fff',
            border: 'none',
            borderRadius: '5px',
            padding: '8px 12px',
            fontSize: '16px',
            cursor: 'pointer',
            transition: 'background-color 0.3s ease',
        },
        adminHeaderInfo: {
            display: 'flex',
            alignItems: 'center',
        },
        adminName: {
            marginRight: '10px',
            fontSize: '16px',
            fontWeight: 'bold',
            color: '#34495e',
        },
        profilePicHeader: {
            width: '40px',
            height: '40px',
            borderRadius: '50%',
            backgroundColor: '#3498db',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '18px',
            cursor: 'pointer', 
        },
    };
    return (
        <div style={styles.dashboardContainer}>
            {/* Sidebar */}
            <div style={styles.sidebar}>
                <div style={styles.sidebarHeader}>
                    <h2 style={styles.sidebarHeaderH2}>Student Analytics</h2>
                    <div style={styles.profileSection}>
                        {/* <div style={styles.profilePic}>AD</div> */}
                    </div>
                </div>
                {/* <p style={styles.sidebarHeaderP}>Admin Dashboard</p> */}
                <div style={styles.sidebarMenu}>
                    <ul style={styles.sidebarMenuUl}>
                        <li style={styles.sidebarMenuLi}>
                            <a href="#" style={{ ...styles.sidebarMenuA, ...styles.sidebarMenuActive }}>
                                <i className="fas fa-tachometer-alt" style={styles.mainIcons}></i>Dashboard
                            </a>
                        </li>
                        <li style={styles.sidebarMenuLi}>
                            <a href="#" style={styles.sidebarMenuA}>
                                <i className="fas fa-user-graduate" style={styles.mainIcons}></i>Students
                            </a>
                        </li>
                        <li style={styles.sidebarMenuLi}>
                            <a href="#" style={styles.sidebarMenuA}>
                                <i className="fas fa-building" style={styles.mainIcons}></i>Departments
                            </a>
                        </li>
                    </ul>
                </div>
                <div style={styles.sidebarAnalytics}>
                    <p style={styles.sidebarAnalyticsP}>ANALYTICS</p>
                    <ul style={styles.sidebarAnalyticsUl}>
                        <li style={styles.sidebarAnalyticsLi}>
                            <a href="#" style={styles.sidebarAnalyticsA}>
                                <i className="fas fa-chart-bar" style={styles.mainIcons}></i>Placements
                            </a>
                        </li>
                        <li style={styles.sidebarAnalyticsLi}>
                            <a href="#" style={styles.sidebarAnalyticsA}>
                                <i className="fas fa-calendar-alt" style={styles.mainIcons}></i>Events
                            </a>
                        </li>
                        <li style={styles.sidebarAnalyticsLi}>
                            <a href="#" style={styles.sidebarAnalyticsA}>
                                <i className="fas fa-newspaper" style={styles.mainIcons}></i>Publications
                            </a>
                        </li>
                        <li style={styles.sidebarAnalyticsLi}>
                            <a href="#" style={styles.sidebarAnalyticsA}>
                                <i className="fas fa-users" style={styles.mainIcons}></i>Societies
                            </a>
                        </li>
                    </ul>
                </div>
                <div style={styles.sidebarSettings}>
                    <p style={styles.sidebarSettingsP}>SETTINGS</p>
                    <ul style={styles.sidebarSettingsUl}>
                        <li style={styles.sidebarSettingsLi}>
                            <a href="#" style={styles.sidebarSettingsA}>
                                <i className="fas fa-cog" style={styles.mainIcons}></i>Preferences
                            </a>
                        </li>
                        <li style={styles.sidebarSettingsLi}>
                            <a href="#" style={styles.sidebarSettingsA}>
                                <i className="fas fa-question-circle" style={styles.mainIcons}></i>Help
                            </a>
                        </li>
                    </ul>
                </div>
                {/* <div style={styles.sidebarAdmin}>

                    <div style={styles.adminIcon}>AD</div>
                    <div style={styles.adminInfo}>
                        <p style={styles.adminInfoP}>Admin User</p>
                        <p style={styles.adminInfoPLastChild}>System Administrator</p>
                    </div>

                </div> */}

            </div>

            {/* Main Content */}
            <div style={styles.mainContent}>
                <header style={styles.dashboardHeader}>
                    <h1 style={styles.dashboardHeaderH1}>Student Analytics Dashboard</h1>
                    <div style={styles.adminHeaderInfo}>
                        <span style={styles.adminName}>Admin User</span>
                        <div style={styles.profilePicHeader}>AD</div>
                    </div>
                </header>

                {/* Quick Stats */}
                <div style={styles.quickStats}>
                    <div style={styles.statCard}>
                        <h3 style={styles.statCardH3}>Total Students</h3>
                        <p style={styles.statCardP}>1,245</p>
                        <p style={styles.statCardPLastChild}>All departments</p>
                    </div>
                    <div style={styles.statCard}>
                        <h3 style={styles.statCardH3}>Placement Rate</h3>
                        <p style={styles.statCardP}>92%</p>
                        <p style={styles.statCardPLastChild}>2024-2025 batch</p>
                    </div>
                    <div style={styles.statCard}>
                        <h3 style={styles.statCardH3}>Events Participation</h3>
                        <p style={styles.statCardP}>78%</p>
                        <p style={styles.statCardPLastChild}>Co-curricular</p>
                    </div>
                    <div style={styles.statCard}>
                        <h3 style={styles.statCardH3}>Publications</h3>
                        <p style={styles.statCardP}>156</p>
                        <p style={styles.statCardPLastChild}>Total count</p>
                    </div>
                </div>... {/* Filters */}
                <div style={styles.filtersContainer}>
                    <label htmlFor="department" style={styles.filterLabel}>
                        Department:
                    </label>
                    <select id="department" style={styles.filterSelect}>
                        <option>All Departments</option>
                    </select>
                    <label htmlFor="batch" style={styles.filterLabel}>
                        Batch:
                    </label>
                    <select id="batch" style={styles.filterSelect}>
                        <option>All</option>
                    </select>
                    <label htmlFor="period" style={styles.filterLabel}>
                        Period:
                    </label>
                    <select id="period" style={styles.filterSelect}>
                        <option>Current Year</option>
                    </select>
                    <label htmlFor="event" style={styles.filterLabel}>
                        Event:
                    </label>
                    <select id="event" style={styles.filterSelect}>
                        <option>All Events</option>
                    </select>
                    <button style={styles.applyFiltersButton}>Apply Filters</button>
                </div>

                {/* Data Visualizations (Placeholders) */}
                <div style={styles.dataVisualizations}>
                    <div style={styles.dataCard}>
                        <h3 style={styles.dataCardH3}>Placements by Company</h3>
                       
                        <div style={styles.chartPlaceholder}>Chart here</div>
                    </div>
                    <div style={styles.dataCard}>
                        <h3 style={styles.dataCardH3}>Event Participation</h3>
                        
                        <div style={styles.chartPlaceholder}>Chart here</div>
                    </div>
                    <div style={styles.dataCard}>
                        <h3 style={styles.dataCardH3}>Publications Trend</h3>
                      
                        <div style={styles.chartPlaceholder}>Chart here</div>
                    </div>
                    <div style={styles.dataCard}>
                        <h3 style={styles.dataCardH3}>Society Membership</h3>
                   
                        <div style={styles.chartPlaceholder}>Chart here</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
