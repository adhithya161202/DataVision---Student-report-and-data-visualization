import React, { useState } from 'react';

function Registration() {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [email, setEmail] = useState('');
    const [username, setUsername] = useState('');
    const [role, setRole] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [termsAgreed, setTermsAgreed] = useState(false);

    const handleSubmit = (event) => {
        event.preventDefault();
        // Add your submission logic here
        console.log('Form submitted:', {
            firstName,
            lastName,
            email,
            username,
            role,
            password,
            confirmPassword,
            termsAgreed,
        });
    };

    return (
        <div style={styles.container}>
            <div style={styles.formContainer}>
              <div style={styles.titleBox}>
                <h2 style={styles.title}>Create a new account</h2>
                </div>
                <form onSubmit={handleSubmit} style={styles.form}>
                    <div style={styles.nameContainer}>
                        <div style={styles.formGroup}>
                            <label htmlFor="firstName" style={styles.label}>First Name</label>
                            <input
                                type="text"
                                id="firstName"
                                value={firstName}
                                onChange={(e) => setFirstName(e.target.value)}
                                style={styles.input}
                            />
                        </div>
                        <div style={styles.formGroup}>
                            <label htmlFor="lastName" style={styles.label}>Last Name</label>
                            <input
                                type="text"
                                id="lastName"
                                value={lastName}
                                onChange={(e) => setLastName(e.target.value)}
                                style={styles.input}
                            />
                        </div>
                    </div>
                    <div style={styles.formGroup}>
                        <label htmlFor="email" style={styles.label}>Email Address</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            style={styles.input}
                        />
                    </div>
                    <div style={styles.nameContainer}>
                        <div style={styles.formGroup}>
                            <label htmlFor="username" style={styles.label}>Username</label>
                            <input
                                type="text"
                                id="username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                style={styles.input}
                            />
                        </div>
                        {/* <div style={styles.formGroup}>
                            <label htmlFor="role" style={styles.label}>Role</label>
                            <select
                                id="role"
                                value={role}
                                onChange={(e) => setRole(e.target.value)}
                                style={styles.input}
                            >
                                <option value="">Select your role</option>
                                <option value="faculty">Faculty</option>
                                <option value="administrator">Administrator</option>
                            </select>
                        </div> */}
                    </div>
                    
                    <div style={styles.formGroup}>
                        <label htmlFor="password" style={styles.label}>Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            style={styles.input}
                        />
                        <p style={styles.passwordNote}>
                            Password must be at least 8 characters long and include uppercase, lowercase,
                            number, and special character.
                        </p>
                    </div>
                    <div style={styles.formGroup}>
                        <label htmlFor="confirmPassword" style={styles.label}>Confirm Password</label>
                        <input
                            type="password"
                            id="confirmPassword"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            style={styles.input}
                        />
                    </div>
                    <div style={styles.termsContainer}>
                        <input
                            type="checkbox"
                            id="terms"
                            checked={termsAgreed}
                            onChange={(e) => setTermsAgreed(e.target.checked)}
                            style={styles.checkbox}
                        />
                        <label htmlFor="terms" style={styles.termsLabel}>
                            I agree to the <a href="#" style={styles.link}>Terms of Service</a> and{' '}
                            <a href="#" style={styles.link}>Privacy Policy</a>. I understand that my
                            data will be stored and processed according to the institution's data
                            policies.
                        </label>
                    </div>
                    <button type="submit" style={styles.button}>Create Account</button>
                </form>
            </div>
        </div>
    );
}

const styles = {
    container: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: '#f0f2f5',
    },
    formContainer: {
        width: '80%',
        maxWidth: '700px',
        padding: '30px',
        backgroundColor: '#fff',
        borderRadius: '8px',
        boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)',
    },
    titleBox: {
        backgroundColor: '#2c3e50',
        color: '#fff',
        padding: '10px',
        borderRadius: '5px',
        marginBottom: '20px',
        textAlign: 'center',
    },
    title: {
        fontSize: '28px',
        fontWeight: '600',
        
        marginBottom: '20px',
        textAlign: 'center',
    },
    form: {
        display: 'flex',
        flexDirection: 'column',
        gap: '15px',
    },
    nameContainer: {
        display: 'flex',
        gap: '15px',
    },
    formGroup: {
        flex: '1',
        display: 'flex',
        flexDirection: 'column',
    },
    label: {
        fontSize: '16px',
        color: '#555',
        marginBottom: '5px',
    },
    input: {
        padding: '12px',
        fontSize: '16px',
        border: '1px solid #ddd',
        borderRadius: '4px',
        outline: 'none',
    },
    passwordNote: {
        fontSize: '12px',
        color: '#777',
        marginTop: '5px',
    },
    termsContainer: {
        display: 'flex',
        alignItems: 'center',
        gap: '10px',
    },
    checkbox: {
        width: '20px',
        height: '20px',
    },
    termsLabel: {
        fontSize: '14px',
        color: '#555',
    },
    link: {
        color: '#007bff',
        textDecoration: 'none',
    },
    button: {
        backgroundColor: '#007bff',
        color: '#fff',
        padding: '15px 20px',
        border: 'none',
        borderRadius: '5px',
        fontSize: '18px',
        cursor: 'pointer',
        marginTop: '20px',
    },
};

export default Registration;
