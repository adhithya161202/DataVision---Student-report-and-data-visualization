package com.example.project.controller;

import com.example.project.model.Publication;
import com.example.project.service.PublicationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/publications")
public class PublicationController {

    private final PublicationService publicationService;

    public PublicationController(PublicationService publicationService) {
        this.publicationService = publicationService;
    }

    @GetMapping
    public List<Publication> getAllPublications() {
        return publicationService.getAllPublications();
    }

    @GetMapping("/year/{year}")
    public List<Publication> getPublicationsByYear(@PathVariable int year) {
        return publicationService.getPublicationsByYear(year);
    }
}
