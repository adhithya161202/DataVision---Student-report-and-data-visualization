
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './Login.css'; 

function Login() {
    const [usernameOrEmail, setUsernameOrEmail] = useState('');
    const [password, setPassword] = useState('');

    const navigate = useNavigate();

    const handleUsernameOrEmailChange = (event) => {
        setUsernameOrEmail(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        navigate('/Dashboard');

        console.log('Username or Email:', usernameOrEmail);
        console.log('Password:', password);
    };

    return (
        <div className="container">
            <div className="LoginBox">
                <div className="headerBox">
                    <h1 className="title">DATA VISION</h1>
                    <p className="subtitle">Login to access the dashboard</p>
                </div>
                <form onSubmit={handleSubmit} className="form">
                    <div className="formGroup">
                        <label htmlFor="usernameOrEmail" className="label">Username or Email</label>
                        <input
                            type="text"
                            id="usernameOrEmail"
                            value={usernameOrEmail}
                            onChange={handleUsernameOrEmailChange}
                            className="input"
                        />
                    </div>
                    <div className="formGroup">
                        <label htmlFor="password" className="label">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={handlePasswordChange}
                            className="input"
                        />
                    </div>
                    <button type="submit" className="button">Login</button>
                </form>
                <div className="footerLinks">
                    <a href="#" className="link">Forgot Password?</a>
                    <span className="linkSeparator">|</span>
                    <Link to="/Registration" className="link">Create Account</Link>
                </div>
            </div>
        </div>
    );
}

export default Login;
