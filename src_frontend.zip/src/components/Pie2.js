import React, { useState } from "react";
import { Pie, Bar } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

const SocietyChart = ({ data }) => {
  const [chartType, setChartType] = useState("pie");

  // Handle empty or invalid data gracefully
  if (!data || data.length === 0) {
    return <p>No society data available</p>;
  }

  // Generate chart data dynamically based on the provided data
  // const chartData = {
  //   labels: [...new Set(data.map(society => society.societyName))], // Unique society names
  //   datasets: [
  //     {
  //       data: data.reduce((acc, society) => {
  //         const index = acc.labels.indexOf(society.societyName);
  //         if (index === -1) {
  //           acc.labels.push(society.societyName);
  //           acc.data.push(1); // Initialize count
  //         } else {
  //           acc.data[index] += 1; // Increment count
  //         }
  //         return acc;
  //       }, { labels: [], data: [] }).data,
  //       backgroundColor: ["#4285F4", "#34A853", "#EA4335", "#FBBC05", "#9CA3AF"],
  //       hoverBackgroundColor: ["#357AE8", "#2E8B57", "#D62D20", "#F4B400", "#6B7280"],
  //     },
  //   ],
  // };


  const chartData = {
    labels: [...new Set(data.map(society => society.societyName))], // Unique society names
    datasets: [
      {
        data: data.reduce((acc, society) => {
          const index = acc.labels.indexOf(society.societyName);
          if (index === -1) {
            acc.labels.push(society.societyName); // Add new society name
            acc.data.push(1); // Initialize count
          } else {
            acc.data[index] += 1; // Increment count for existing society
          }
          return acc;
        }, { labels: [], data: [] }).data,
        backgroundColor: ["#4285F4", "#34A853", "#EA4335", "#FBBC05", "#9CA3AF"],
        hoverBackgroundColor: ["#357AE8", "#2E8B57", "#D62D20", "#F4B400", "#6B7280"],
      },
    ],
  };
  

  return (
    <div style={styles.chartContainer}>
      <div style={styles.buttonGroup}>
        <button
          onClick={() => setChartType("bar")}
          style={chartType === "bar" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Bar
        </button>
        <button
          onClick={() => setChartType("pie")}
          style={chartType === "pie" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Pie
        </button>
      </div>
      <div style={styles.chart}>
        {chartType === "pie" ? <Pie data={chartData} /> : <Bar data={chartData} />}
      </div>
    </div>
  );
};

// Inline CSS styles for the chart component
const styles = {
  chartContainer: {
    textAlign: "center",
    margin: "20px auto",
    width: "60%",
  },
  heading: {
    fontSize: "20px",
    fontWeight: "bold",
  },
  buttonGroup: {
    marginBottom: "15px",
  },
  button: {
    margin: "5px",
    padding: "8px 16px",
    border: "none",
    cursor: "pointer",
    backgroundColor: "#e0e0e0",
    borderRadius: "5px",
  },
  activeButton: {
    backgroundColor: "#007bff",
    color: "white",
  },
  chart: {
    display: "flex",
    justifyContent: "center",
  },
};

export default SocietyChart;
