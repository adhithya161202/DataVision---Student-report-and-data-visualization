import React, { useState } from "react";
import { Pie, Bar } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from "chart.js";

// Register all necessary components
ChartJS.register(
  ArcElement, Tooltip, Legend, 
  CategoryScale, LinearScale, BarElement
);

// const PlacementChart = () => {
//   const [chartType, setChartType] = useState("pie");

//   const data = {
//     labels: ["Google", "Microsoft", "Amazon", "IBM", "Other"],
//     datasets: [
//       {
//         data: [20, 15, 15, 10, 40], // Example values
//         backgroundColor: ["#4285F4", "#34A853", "#EA4335", "#FBBC05", "#9CA3AF"],
//         hoverBackgroundColor: ["#357AE8", "#2E8B57", "#D62D20", "#F4B400", "#6B7280"],
//       },
//     ],
//   };

const PlacementChart = ({ data }) => {
  const [chartType, setChartType] = useState("pie");

  console.log("Chart Data:", data);
  if (!data || data.length === 0) {
    return <p>No placement data available</p>;
  }

  const chartData = {
    labels: [...new Set(data.map(placement => placement.company))],
    datasets: [{
      label: 'Placements by Company',
      data: data.reduce((acc, placement) => {
        const index = acc.labels.indexOf(placement.company);
        if (index === -1) {
          acc.labels.push(placement.company);
          acc.data.push(1);
        } else {
          acc.data[index] += 1;
        }
        return acc;
      }, { labels: [], data: [] }).data,
      backgroundColor: [
        '#4285F4', 
        '#34A853', 
        '#EA4335', 
        '#FBBC05', 
        '#9CA3AF',
        '#4A148C',
        '#FF5733',
        '#00C8FF',
        '#FFC300',
        '#8E44AD'
      ],
    }],
  };




  return (
    <div style={styles.chartContainer}>
      <div style={styles.buttonGroup}>
        <button
          onClick={() => setChartType("bar")}
          style={chartType === "bar" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Bar
        </button>
        <button
          onClick={() => setChartType("pie")}
          style={chartType === "pie" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Pie
        </button>
      </div>
      <div style={styles.chart}>
        {chartType === "pie" ? <Pie data={chartData} /> : <Bar data={chartData} />}
      </div>
    </div>
  );
};

// Inline CSS styles
const styles = {
  chartContainer: {
    textAlign: "center",
    margin: "20px auto",
    width: "60%",
  },
  heading: {
    fontSize: "20px",
    fontWeight: "bold",
  },
  buttonGroup: {
    marginBottom: "15px",
  },
  button: {
    margin: "5px",
    padding: "8px 16px",
    border: "none",
    cursor: "pointer",
    backgroundColor: "#e0e0e0",
    borderRadius: "5px",
  },
  activeButton: {
    backgroundColor: "#007bff",
    color: "white",
  },
  chart: {
    display: "flex",
    justifyContent: "center",
  },
};

export default PlacementChart;
