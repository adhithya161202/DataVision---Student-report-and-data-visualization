import axios from 'axios';

const API_URL = 'http://localhost:8080/api/publications';

const PublicationService = {
  getAllPublications: () => axios.get(API_URL),
  getPublicationsByYear: (year) => axios.get(`${API_URL}/year/${year}`),
};

export default PublicationService;
