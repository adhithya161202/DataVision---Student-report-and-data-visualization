import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Login() {
    const [usernameOrEmail, setUsernameOrEmail] = useState('');
    const [password, setPassword] = useState('');

    const navigate = useNavigate();

    const handleUsernameOrEmailChange = (event) => {
        setUsernameOrEmail(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        navigate('/Dashboard');

        console.log('Username or Email:', usernameOrEmail);
        console.log('Password:', password);
    };

    return (
        <div style={styles.container}>
            <div style={styles.LoginBox}>
                <div style={styles.headerBox}>
                    <h1 style={styles.title}>Student Analytics</h1>
                    <p style={styles.subtitle}>Login to access the dashboard</p>
                </div>
                <form onSubmit={handleSubmit} style={styles.form}>
                    <div style={styles.formGroup}>
                        <label htmlFor="usernameOrEmail" style={styles.label}>Username or Email</label>
                        <input
                            type="text"
                            id="usernameOrEmail"
                            value={usernameOrEmail}
                            onChange={handleUsernameOrEmailChange}
                            style={styles.input}
                        />
                    </div>
                    <div style={styles.formGroup}>
                        <label htmlFor="password" style={styles.label}>Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={handlePasswordChange}
                            style={styles.input}
                        />
                    </div>
                    <button type="submit" style={styles.button}>Login</button>
                </form>
                <div style={styles.footerLinks}>
                    <a href="#" style={styles.link}>Forgot Password?</a>
                    <span style={styles.linkSeparator}>|</span>
                    <Link to="/Registration" style={styles.link}>Create Account</Link>
                </div>
            </div>
        </div>
    );
}

const styles = {
    container: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: '#f0f2f5',
    },
    LoginBox: {
        width: '500px', // Adjusted width
        height: '600px',// Adjusted height
        padding: '40px',
        backgroundColor: '#fff',
        borderRadius: '5px',
        boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
    },
    headerBox: {
        backgroundColor: '#2c3e50',
        color: '#fff',
        padding: '30px',
        borderRadius: '5px',
        marginBottom: '30px',
        textAlign: 'center',
    },
    title: {
        fontSize: '30px',
        fontWeight: 'bold',
        marginBottom: '5px',
    },
    subtitle: {
        fontSize: '16px',
    },
    form: {
        display: 'flex',
        flexDirection: 'column',
        padding: '10px'
    },
    formGroup: {
        marginBottom: '15px',
        textAlign: 'left', // Align label to the left
    },
    label: {
        fontSize: '15px',
        marginBottom: '5px',
        color: '#333',
        display: 'block', 
        textAlign: 'left',
    },
    input: {
        padding: '10px',
        fontSize: '14px',
        borderRadius: '3px',
        border: '1px solid #ccc',
        width: '100%', 
        boxSizing: 'border-box', 
    },
    button: {
        backgroundColor: '#3498db',
        color: 'white',
        padding: '10px 15px',
        border: 'none',
        borderRadius: '3px',
        fontSize: '18px',
        cursor: 'pointer',
    },
    footerLinks: {
        marginTop: '15px',
        textAlign: 'center',
    },
    link: {
        color: '#3498db',
        fontSize: '14px',
        textDecoration: 'none',
        margin: '0 10px',
    },
    linkSeparator: {
        color: '#ccc',
        margin: '0 5px',
    },
};

export default Login;
