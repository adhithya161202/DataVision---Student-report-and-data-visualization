import React, { useState } from "react";
import { Pie, Bar } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

const SocietyChart = () => {
  const [chartType, setChartType] = useState("pie");

  const data = {
    labels: ["IEEE", "IEDC", "ISTE", "RIG", "Other"],
    datasets: [
      {
        data: [20, 15, 15, 10, 40], 
        backgroundColor: ["#4285F4", "#34A853", "#EA4335", "#FBBC05", "#9CA3AF"],
        hoverBackgroundColor: ["#357AE8", "#2E8B57", "#D62D20", "#F4B400", "#6B7280"],
      },
    ],
  };

  return (
    <div style={styles.chartContainer}>
      <div style={styles.buttonGroup}>
        <button
          onClick={() => setChartType("bar")}
          style={chartType === "bar" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Bar
        </button>
        <button
          onClick={() => setChartType("pie")}
          style={chartType === "pie" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Pie
        </button>
      </div>
      <div style={styles.chart}>
        {chartType === "pie" ? <Pie data={data} /> : <Bar data={data} />}
      </div>
    </div>
  );
};

// Inline CSS styles
const styles = {
  chartContainer: {
    textAlign: "center",
    margin: "20px auto",
    width: "60%",
  },
  heading: {
    fontSize: "20px",
    fontWeight: "bold",
  },
  buttonGroup: {
    marginBottom: "15px",
  },
  button: {
    margin: "5px",
    padding: "8px 16px",
    border: "none",
    cursor: "pointer",
    backgroundColor: "#e0e0e0",
    borderRadius: "5px",
  },
  activeButton: {
    backgroundColor: "#007bff",
    color: "white",
  },
  chart: {
    display: "flex",
    justifyContent: "center",
  },
};

export default SocietyChart;
