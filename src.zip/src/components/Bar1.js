import React, { useState } from "react";
import { Bar, Pie } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

const EventParticipationChart = () => {
  const [chartType, setChartType] = useState("bar");

  const data = {
    labels: ["Hackathon", "Workshop", "Cultural", "Sports", "Debate"],
    datasets: [
      {
        label: "Participants",
        data: [320, 280, 390, 260, 130], 
        backgroundColor: ["#4285F4", "#34A853", "#EA4335", "#FBBC05", "#9B59B6"],
        hoverBackgroundColor: ["#357AE8", "#2E8B57", "#D62D20", "#F4B400", "#8E44AD"],
      },
    ],
  };

  return (
    <div style={styles.chartContainer}>
      <h3 style={styles.heading}>Event Participation</h3>
      <div style={styles.buttonGroup}>
        <button
          onClick={() => setChartType("bar")}
          style={chartType === "bar" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Bar
        </button>
        <button
          onClick={() => setChartType("pie")}
          style={chartType === "pie" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Pie
        </button>
      </div>
      <div style={styles.chart}>
        {chartType === "bar" ? <Bar data={data} /> : <Pie data={data} />}
      </div>
    </div>
  );
};


const styles = {
  chartContainer: {
    textAlign: "center",
    margin: "20px auto",
    width: "70%",
  },
  heading: {
    fontSize: "20px",
    fontWeight: "bold",
  },
  buttonGroup: {
    marginBottom: "15px",
  },
  button: {
    margin: "5px",
    padding: "8px 16px",
    border: "none",
    cursor: "pointer",
    backgroundColor: "#e0e0e0",
    borderRadius: "5px",
  },
  activeButton: {
    backgroundColor: "#007bff",
    color: "white",
  },
  chart: {
    display: "flex",
    justifyContent: "center",
  },
};

export default EventParticipationChart;
