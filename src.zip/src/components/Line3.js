import React, { useState } from "react";
import { Bar, Line } from "react-chartjs-2";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

const PublicationsTrendChart = () => {
  const [chartType, setChartType] = useState("line");

  const data = {
    labels: ["2020", "2021", "2022", "2023", "2024"],
    datasets: [
      {
        label: "Journal",
        data: [18, 22, 27, 33, 40], 
        backgroundColor: "#4285F4",
        borderColor: "#4285F4",
        fill: true,
        tension: 0.3,
      },
      {
        label: "Conference",
        data: [25, 35, 40, 45, 50], 
        backgroundColor: "#34A853",
        borderColor: "#34A853",
        fill: true,
        tension: 0.3,
      },
    ],
  };

  return (
    <div style={styles.chartContainer}>
      <h3 style={styles.heading}>Publications Trend</h3>
      <div style={styles.buttonGroup}>
        <button
          onClick={() => setChartType("line")}
          style={chartType === "line" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Line
        </button>
        <button
          onClick={() => setChartType("bar")}
          style={chartType === "bar" ? { ...styles.button, ...styles.activeButton } : styles.button}
        >
          Bar
        </button>
      </div>
      <div style={styles.chart}>
        {chartType === "line" ? <Line data={data} /> : <Bar data={data} />}
      </div>
    </div>
  );
};

const styles = {
  chartContainer: {
    textAlign: "center",
    margin: "20px auto",
    width: "70%",
  },
  heading: {
    fontSize: "20px",
    fontWeight: "bold",
  },
  buttonGroup: {
    marginBottom: "15px",
  },
  button: {
    margin: "5px",
    padding: "8px 16px",
    border: "none",
    cursor: "pointer",
    backgroundColor: "#e0e0e0",
    borderRadius: "5px",
  },
  activeButton: {
    backgroundColor: "#007bff",
    color: "white",
  },
  chart: {
    display: "flex",
    justifyContent: "center",
  },
};

export default PublicationsTrendChart;
